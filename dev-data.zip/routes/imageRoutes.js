const express = require('express');

const router = express.Router();

router.route('/:type/:id').get((req, res, next) => {
  // res.set({ 'Content-Type': 'image/png' });
  res.sendFile(`img/${req.params.type}/${req.params.id}`);
});

module.exports = router;
